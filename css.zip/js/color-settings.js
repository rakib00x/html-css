(function ($) {
    "use strict";
	
	
    $('.calculator-trigger').on('click', function () {
        $(this).parent().toggleClass('visible-palate');
    });
	
	

}(jQuery));